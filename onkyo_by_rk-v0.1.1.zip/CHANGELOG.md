# Changelog

## 0.1.1 — Initial release
- First public release of Onkyo by RK
- Media player–first architecture (connect → discover → forward)
- eISCP transport (connect/ping, power on/off, volume step)
- Config Flow with SSDP/Zeroconf discovery
- Services: dump_capabilities, debug_files
