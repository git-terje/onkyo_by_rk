from __future__ import annotations
DOMAIN = "onkyo_by_rk"
PLATFORMS: list[str] = ["media_player"]
DEFAULT_PORT = 60128
DEFAULT_ZONE = "1"
DEFAULT_RESOLUTION = 80
