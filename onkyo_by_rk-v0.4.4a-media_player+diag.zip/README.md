# Onkyo by RK — v0.4.4a (media_player + diagnostics)

Som v0.4.4, men med ekstra service: `onkyo_by_rk.debug_files` som logger hvilke filer
HA faktisk ser under `custom_components/onkyo_by_rk`. Bruk den for å verifisere at
det ikke finnes gamle `number.py`-rester.
