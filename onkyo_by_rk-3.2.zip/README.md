# Onkyo by RK (v3.2)

Custom Home Assistant integration for Onkyo receivers.
- Dynamic, no hardcoding
- Receiver object is stored before platforms load (pre-0.4 pattern restored)
- Debug messages at INFO/DEBUG to help troubleshooting

## Install
1. Upload the `custom_components/onkyo_by_rk` folder to your Home Assistant.
2. Restart Home Assistant.
3. Go to **Settings → Devices & Services → Add Integration** and select **Onkyo by RK**.
4. Enter `host` and (optional) `port` (default 60128).

## Logging
Recommended in `configuration.yaml`:
```yaml
logger:
  default: warning
  logs:
    custom_components.onkyo_by_rk: debug
```

## Notes
- `receiver.py` is a non-blocking stub; replace transport with real eISCP later.
- The Number platform exposes a single **Max Volume** entity driven by receiver capabilities.
