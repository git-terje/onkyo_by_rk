import logging
from homeassistant.components.number import NumberEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN

_LOGGER = logging.getLogger(__package__)

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    data = hass.data.get(DOMAIN, {}).get(entry.entry_id)
    if not data:
        _LOGGER.error("[onkyo_by_rk][number] No data for entry_id=%s", entry.entry_id)
        return
    receiver = data.get("receiver")
    if not receiver:
        _LOGGER.error("[onkyo_by_rk][number] Receiver missing for entry_id=%s", entry.entry_id)
        return

    entities = []
    if hasattr(receiver, "max_volume"):
        entities.append(OnkyoMaxVolumeNumber(receiver))

    if entities:
        async_add_entities(entities, update_before_add=False)
        _LOGGER.debug("[onkyo_by_rk][number] %d entities added", len(entities))
    else:
        _LOGGER.debug("[onkyo_by_rk][number] No entities created")

class OnkyoMaxVolumeNumber(NumberEntity):
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, receiver) -> None:
        self._rx = receiver
        self._attr_name = f"{receiver.name} Max Volume"
        self._attr_unique_id = f"{receiver.unique_id}_max_volume"
        self._attr_native_min_value = getattr(receiver, "volume_min", 0)
        self._attr_native_max_value = getattr(receiver, "volume_max", 100)
        self._attr_native_step = getattr(receiver, "volume_step", 1)
        self._native_value = float(getattr(receiver, "max_volume", 80))

    @property
    def native_value(self) -> float:
        return float(self._native_value)

    async def async_set_native_value(self, value: float) -> None:
        await self._rx.set_max_volume(int(value))
        self._native_value = float(value)
        self.async_write_ha_state()
