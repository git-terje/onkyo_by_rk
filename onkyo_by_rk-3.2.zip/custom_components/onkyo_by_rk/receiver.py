import asyncio
import logging

_LOGGER = logging.getLogger(__package__)

class OnkyoReceiver:
    """Minimal async receiver stub for setup validation.
    Replace transport with real eISCP/ISCP implementation later.
    """
    def __init__(self, host: str, port: int = 60128) -> None:
        self.host = host
        self.port = port
        self.name = f"Onkyo {host}"
        self.unique_id = f"onkyo_{host.replace('.', '_')}_{port}"
        # Dynamic capabilities
        self.volume_min = 0
        self.volume_max = 100
        self.volume_step = 1
        self.volume = 20
        self.max_volume = 80
        self.speakers = []   # populated dynamically later
        self.sources = []    # populated dynamically later
        self._connected = False

    async def connect(self) -> None:
        _LOGGER.info("[onkyo_by_rk] Connecting to %s:%s", self.host, self.port)
        await asyncio.sleep(0)  # yield
        self._connected = True
        _LOGGER.info("[onkyo_by_rk] Connected to %s:%s (stub)", self.host, self.port)

    async def set_volume(self, value: float) -> None:
        _LOGGER.debug("[onkyo_by_rk] set_volume(%s)", value)
        self.volume = max(self.volume_min, min(self.volume_max, int(value)))

    async def set_max_volume(self, value: int) -> None:
        _LOGGER.debug("[onkyo_by_rk] set_max_volume(%s)", value)
        self.max_volume = max(self.volume_min, min(self.volume_max, int(value)))

    def get_speaker_level(self, channel: str) -> float:
        return 0.0

    async def set_speaker_level(self, channel: str, value: float) -> None:
        _LOGGER.debug("[onkyo_by_rk] set_speaker_level(%s, %s)", channel, value)
        return
