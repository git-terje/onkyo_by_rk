import logging
from homeassistant.components.media_player import MediaPlayerEntity
from homeassistant.components.media_player.const import MediaPlayerEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN

_LOGGER = logging.getLogger(__package__)

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    data = hass.data.get(DOMAIN, {}).get(entry.entry_id)
    if not data:
        _LOGGER.error("[onkyo_by_rk][media_player] No data for %s", entry.entry_id)
        return
    receiver = data.get("receiver")
    if not receiver:
        _LOGGER.error("[onkyo_by_rk][media_player] Receiver missing for %s", entry.entry_id)
        return

    async_add_entities([OnkyoMediaPlayer(receiver)], update_before_add=False)
    _LOGGER.debug("[onkyo_by_rk][media_player] Entity created for %s", receiver.host)

class OnkyoMediaPlayer(MediaPlayerEntity):
    _attr_supported_features = MediaPlayerEntityFeature.VOLUME_SET | MediaPlayerEntityFeature.VOLUME_STEP

    def __init__(self, receiver) -> None:
        self._rx = receiver
        self._attr_name = getattr(receiver, "name", "Onkyo Receiver")
        self._attr_unique_id = getattr(receiver, "unique_id", None)

    @property
    def volume_level(self) -> float:
        vmax = getattr(self._rx, "volume_max", 100) or 100
        return float(getattr(self._rx, "volume", 0)) / float(vmax)

    async def async_set_volume_level(self, volume: float) -> None:
        vmax = getattr(self._rx, "volume_max", 100) or 100
        await self._rx.set_volume(volume * vmax)

    async def async_volume_up(self) -> None:
        await self._rx.set_volume(min(self._rx.volume_max, self._rx.volume + self._rx.volume_step))

    async def async_volume_down(self) -> None:
        await self._rx.set_volume(max(self._rx.volume_min, self._rx.volume - self._rx.volume_step))

    @property
    def available(self) -> bool:
        return True
