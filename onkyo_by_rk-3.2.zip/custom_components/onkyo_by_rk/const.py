DOMAIN = "onkyo_by_rk"
PLATFORMS = ["media_player", "number"]
