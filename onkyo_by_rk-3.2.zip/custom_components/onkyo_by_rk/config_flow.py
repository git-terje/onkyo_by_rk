import logging
from typing import Any
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import HomeAssistant
from homeassistant.data_entry_flow import FlowResult

from .const import DOMAIN

_LOGGER = logging.getLogger(__package__)

DATA_SCHEMA = vol.Schema(
    {
        vol.Required("host"): str,
        vol.Optional("port", default=60128): int,
    }
)

class OnkyoConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is None:
            return self.async_show_form(step_id="user", data_schema=DATA_SCHEMA)

        host = user_input["host"]
        port = user_input.get("port", 60128)

        title = f"Onkyo {host}:{port}"
        _LOGGER.info("[onkyo_by_rk][config_flow] Creating entry for %s", title)

        return self.async_create_entry(title=title, data={"host": host, "port": port})
