import logging
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.typing import ConfigType

from .const import DOMAIN, PLATFORMS
from .receiver import OnkyoReceiver

_LOGGER = logging.getLogger(__package__)

async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    return True

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    _LOGGER.info("[onkyo_by_rk] Setting up entry_id=%s", entry.entry_id)
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN].setdefault(entry.entry_id, {})

    host = entry.data.get("host")
    port = entry.data.get("port", 60128)
    if not host:
        _LOGGER.error("[onkyo_by_rk] Missing 'host' in entry %s", entry.entry_id)
        return False

    # Create & store receiver BEFORE forwarding platforms (pre-0.4 pattern)
    receiver = OnkyoReceiver(host=host, port=port)
    try:
        await receiver.connect()
    except Exception as err:
        _LOGGER.error("[onkyo_by_rk] Connection failed %s:%s -> %s", host, port, err)
        return False

    hass.data[DOMAIN][entry.entry_id]["receiver"] = receiver
    _LOGGER.debug("[onkyo_by_rk] Receiver stored for entry_id=%s", entry.entry_id)

    # Forward platform setups
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    _LOGGER.debug("[onkyo_by_rk] Platforms forwarded for entry_id=%s", entry.entry_id)
    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    _LOGGER.info("[onkyo_by_rk] Unloading entry_id=%s", entry.entry_id)
    ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if ok:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
        _LOGGER.debug("[onkyo_by_rk] Entry data cleared for %s", entry.entry_id)
    return ok
