# Onkyo by RK — v0.3.8

- Media_player-first (NG-mønster), discovery før platform.
- Inkluderer sikker stub `number.py` som ikke lager entiteter (hindrer KeyError ved legacy loads).
- Services: `dump_capabilities`, `debug_files`.

**Installer:**
1) Slett gammel mappe `custom_components/onkyo_by_rk/` helt, så pakk ut denne.
2) Full restart av Home Assistant.
3) Legg til integrasjonen (oppdaget eller manuelt).
